<?php
// PruebaMenuSeleccion.php
include_once 'MenuSeleccion.php'; // Incluimos el archivo donde se definen las funciones

// Crear un objeto de la clase Menu
$menu = new Menu();

// Ejecutar el método mostrarMenu() para mostrar el menú
$menu->mostrarMenu();
?>
